khdhrnmfgh.exe
Created by: Pminh141 (Phung Minh)
Made in: C++, asm and more
works in: Windows XP
Malware type: Trojan